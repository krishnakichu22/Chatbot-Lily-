from django.shortcuts import render
from chartbt.chartbot import bot_response
import random

# Create your views here.
def greeting_response(text):

    text = text.lower()

    #boots grettings
    bot_grettings = ['howdy','hi','hey','hola','huh']
    #user grettings
    user_grettings = ['hi','hey','hello','wassup','hola','wassup']

    for word in text.split():
        if word in user_grettings:
            return random.choice(bot_grettings)

def index(request):

    exit_list = ['exit','see you later','bye','break','quit']
    conv=""
    if request.POST:
        conv=request.POST.get('conv','')
        name=request.POST.get('user_name')
        user_input=request.POST.get('user_input','')

        if user_input.lower() in exit_list:
            conv=conv+"You :"+str(user_input)+"\n"+"Lily : Chat with you later!"+"\n"+"\n"
        else:
            if greeting_response(user_input) != None:

                conv=conv+"You :"+str(user_input)+"\n"+'Lily bot: '+greeting_response(user_input)+"\n"+"\n"
            else:
                conv=conv+"You :"+str(user_input)+"\n"+"lily bot: " +bot_response(user_input)+"\n" +"\n"

    return render(request,'index.html',{'conv':conv})
