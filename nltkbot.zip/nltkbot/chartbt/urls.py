from django.urls import path
from chartbt import views


urlpatterns = [
    path('',views.index),
]
